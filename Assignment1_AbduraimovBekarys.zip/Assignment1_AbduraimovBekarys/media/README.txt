This folder is for audio and video files used on the website.
